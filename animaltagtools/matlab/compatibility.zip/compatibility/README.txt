These functions are provided for compatibility with older versions of Matlab/Octave.
Before adding this directory to the Matlab/Octave search path, check if your version
of the software has audioread and spectrogram by typing at the Matlab/Octave prompt:

which audioread
which spectrogram

If audioread exists, delete or rename all of the functions starting with audio in this
directory.
If spectrogram exists, delete or rename the function spectrogram in this directory.
